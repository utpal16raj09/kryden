export default function Features() {
  const features = [
    {
      icon: 'λ',
      title: 'Lattice-Based Integrity',
      description:
        'Leverage the mathematical complexity of lattices for encryption that resists all known quantum and classical attacks.',
    },
    {
      icon: 'Ω',
      title: 'True Quantum Entropy',
      description:
        'Integrate certified quantum randomness for true non-determinism in key generation and cryptographic verification.',
    },
    {
      icon: 'π',
      title: 'Computationally Irreversible',
      description:
        'Transform data into non-derivable, homomorphic representations, rendering data leakage functionally zero.',
    },
    {
      icon: '∑',
      title: 'Multi-Factor Assurances',
      description:
        'Employ cryptographic fusion across transport and storage layers, eliminating single points of failure.',
    },
  ];

  return (
    <section className="py-24 px-6 bg-[#1A1A1A] text-[#F8F5EE] rounded-3xl my-12 mx-6 overflow-hidden relative">
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#00FFFF]/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#FF0099]/5 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-8 flex-wrap">
            <span className="px-4 py-2 bg-[#00FFFF]/20 text-[#00FFFF] rounded-xl text-sm font-mono border border-[#00FFFF]/30">
              λ Lattice-PQC
            </span>
            <span className="px-4 py-2 bg-[#FF0099]/20 text-[#FF0099] rounded-xl text-sm font-mono border border-[#FF0099]/30">
              ∑ Multi-Factor
            </span>
            <span className="px-4 py-2 bg-[#00FFFF]/20 text-[#00FFFF] rounded-xl text-sm font-mono border border-[#00FFFF]/30">
              Ω Entropy-Enhanced
            </span>
          </div>

          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif mb-6 leading-tight">
            Reinventing Data Security at a Fundamental Level
          </h2>

          <p className="text-lg text-gray-400 max-w-3xl mx-auto mb-8 leading-relaxed">
            Modern encryption is no longer enough. Emerging quantum threats, hyper-connected networks, and unprecedented
            data exposure demand a completely new class of protection.
          </p>

          <button className="bg-transparent border-2 border-[#00FFFF] text-[#00FFFF] px-8 py-3 rounded-2xl font-semibold transition-all duration-300 hover:bg-[#00FFFF] hover:text-[#1A1A1A] hover:shadow-[0_0_30px_rgba(0,255,255,0.6)] hover:scale-105">
            View Protocol Architecture
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group bg-[#2A2A2A] p-8 rounded-2xl transition-all duration-500 hover:bg-[#1E3F3A] hover:scale-105 hover:shadow-[0_0_40px_rgba(0,255,255,0.3)] border border-transparent hover:border-[#00FFFF]/30"
              style={{
                animation: `fadeInUp 0.6s ease-out ${index * 0.1}s both`,
              }}
            >
              <div className="w-16 h-16 bg-gradient-to-br from-[#00FFFF] to-[#FF0099] rounded-2xl flex items-center justify-center text-3xl font-bold text-white mb-6 group-hover:rotate-12 transition-transform duration-300">
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-4 text-[#00FFFF]">{feature.title}</h3>
              <p className="text-gray-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
